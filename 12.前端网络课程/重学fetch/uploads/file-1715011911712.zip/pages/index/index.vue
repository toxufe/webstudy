<template>
	<view>
		<page-head :title="title"></page-head>
			<input class="uni-input"  v-model="stringParam" />
			<view class="uni-btn-v uni-common-mt">
				<button type="primary"  @tap="init">初始化</button>
				<button type="primary"  @tap="listen">监听</button>
				<button type="primary"  @tap="start">开始</button>
				<button type="primary"  @tap="stop">结束</button>
				<button type="primary"  @tap="destroy">销毁</button>
			</view>
	</view>
</template>
<script>
	
	import * as UTSRfid from "../../uni_modules/uts-rfid";

	export default {
		data() {
			return {
				title: 'UTS入门示例',
				stringParam:"hello world",
			}
		},
		
		methods: {
			
			/**
			 * 测试无参数调用
			 */
			init: function () {
				UTSRfid.initRfid({result:(msg)=>{
					console.log(msg)
				}});
			},
			listen: function (){
				UTSRfid.listenInventoryTags({result:(data)=>{
					console.log(data.epc)
					console.log(data.tid)
				}});
			}, 
			start: function (){    
				UTSRfid.startInventory({result:(msg)=>{
					console.log(msg)
				}});
			},    
			stop: function (){  
				UTSRfid.stopInventory({result:(msg)=>{
					console.log(msg)
				}});
			}, 
			destroy: function (){
				UTSRfid.destroyRfid({result:(msg)=>{
					console.log(msg)
				}});
			}, 
			
			
		}
	}
</script>

<style>

  
</style>